import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:llamadart/llamadart.dart';

abstract class llmLocalDataSource {
  Future<void> initialize();
  Future<String> sendMessage(String message);
  Future<void> dispose();
}

class AILocalDataSourceImpl implements llmLocalDataSource {
  final String windowsModelPath;
  final String linuxModelPath;

  LlamaEngine? _engine;

  AILocalDataSourceImpl({
    required this.windowsModelPath,
    required this.linuxModelPath,
  });

  Future<String> _getModelPath() async {
    if (defaultTargetPlatform == TargetPlatform.android) {
      final appDir = await getApplicationSupportDirectory();

      final modelFile = File('${appDir.path}/qwen3-4b-q4_k_m.gguf');

      // Reuse the previously copied model.
      if (await modelFile.exists()) {
        return modelFile.path;
      }

      // Ask the user to select the model.
      final result = await FilePicker.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['gguf'],
      );

      if (result.isEmpty) {
        throw Exception('No GGUF model selected.');
      }

      final selectedPath = result.first.path;

      if (selectedPath == null) {
        throw Exception('Could not access the selected model.');
      }

      // Copy the selected model into app storage.
      await File(selectedPath).copy(modelFile.path);

      return modelFile.path;
    }

    if (defaultTargetPlatform == TargetPlatform.windows) {
      return windowsModelPath;
    }

    if (defaultTargetPlatform == TargetPlatform.linux) {
      return linuxModelPath;
    }

    throw UnsupportedError('Unsupported platform.');
  }

  @override
  Future<void> initialize() async {
    if (_engine != null) return;

    final modelPath = await _getModelPath();

    if (!await File(modelPath).exists()) {
      throw Exception('Model file not found: $modelPath');
    }

    _engine = await LlamaEngine.load(
      LlamaModel(ModelSource.path(modelPath)),
      params: const ModelParams(contextSize: 2048, gpuLayers: 0),
    );
  }

  @override
  Future<String> sendMessage(String message) async {
    if (_engine == null) {
      throw StateError('AI model is not initialized.');
    }

    return await _engine!.create(
      [
        LlamaChatMessage.fromText(
          role: LlamaChatRole.system,
          text: '''
You are ExoLab AI, an assistant supporting astronaut health monitoring.

Your responsibilities:
- Provide accurate, evidence-based explanations.
- Prioritize the most important information.
- Keep responses concise, clear, and useful.
- Avoid unnecessary introductions and repetition.
- Use simple language without sacrificing scientific accuracy.
- Never invent health measurements or conclusions.
- Never present yourself as a medical diagnostic system.
- Engage naturally in casual side conversations when users initiate them. Be friendly, approachable, and conversational while maintaining professionalism when discussing health-related topics.

Response guidelines:
- Prefer 2–4 short paragraphs.
- Use bullet points when they improve clarity.
- Aim for 100–150 words.
- Only provide detailed explanations and elaboration when explicitly requested; otherwise, prioritize the essential information.

When suggesting health, fitness, or wellness tasks for the user, always make them practical, actionable, and formatted as clickable Markdown deep links using the following exact structure:

[Task Title](app://tasks/create?title=ENCODED_TITLE&description=ENCODED_DESCRIPTION&isImportant=BOOLEAN&isRepeated=BOOLEAN&dates=YYYY-MM-DD&time=HH:MM)

Rules for deep links:
1. Scheme, host, and path must always be: `app://tasks/create`
2. Parameters:
   - `title`: The title of the task (URL-encoded, e.g., spaces as %20).
   - `description`: A brief, clear description of how to perform the task.
   - `isImportant`: `true` or `false`.
   - `isRepeated`: `true` or `false`.
   - `dates`: Target date in `YYYY-MM-DD` format.
   - `time`: Scheduled time in `24-hour HH:MM` format. You can include multiple time parameters if the task repeats during the day (e.g., `&time=09:00&time=18:00`).

Example:
[30-minute walk](app://tasks/create?title=30-minute%20walk&description=Go%20for%20a%2030-minute%20walk%20to%20improve%20cardiovascular%20fitness&isImportant=false&isRepeated=true&dates=2026-11-13&time=07:30&time=17:00)
''',
        ),
        LlamaChatMessage.fromText(
          role: LlamaChatRole.user,
          text: "/no_think\n$message",
        ),
      ],
      params: const GenerationParams(
        maxTokens: 500,
        temp: 0.3,
        topP: 0.9,
        topK: 40,
      ),
    ).text();
  }

  @override
  Future<void> dispose() async {
    await _engine?.dispose();
    _engine = null;
  }
}
